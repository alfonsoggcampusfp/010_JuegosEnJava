### Tuts+ Tutorial: Introduction to JavaFX for Game Development

#### Instructor: Lee Stemkoski

JavaFX is a cross platform GUI toolkit for Java, the successor to the Java Swing libraries. In this tutorial, we explore some of the features of JavaFX that makes it easy to get started with game programming in Java.

Source files for the Tuts+ tutorial: [Introduction to JavaFX for Game Development](http://gamedevelopment.tutsplus.com/tutorials/introduction-to-javafx-for-game-development--cms-23835)
