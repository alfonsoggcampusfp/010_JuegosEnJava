public class IntValue
{
    public int value;
    
    public IntValue(int i)
    {
        value = i;
    }
}